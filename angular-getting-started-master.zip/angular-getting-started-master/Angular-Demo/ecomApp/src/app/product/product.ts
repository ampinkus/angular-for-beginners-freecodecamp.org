export interface Product {
  id: number;
  name: string;
  mfd: Date;
  price: number;
}
