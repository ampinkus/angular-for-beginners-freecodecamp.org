export class Util {

  constructor(num1: number) {

  }

  add(num1: number, num2: number): number {
    return num1 + num2;
  }
}
