export interface AppConfig {
  apiKey : string;
  backendUrl: string;
}
