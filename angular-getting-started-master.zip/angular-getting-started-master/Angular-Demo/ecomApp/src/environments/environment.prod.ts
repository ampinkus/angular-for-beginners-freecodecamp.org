export const environment = {
  production: true,
  stripe_api_key: 'gdfgdfgdf'
};
